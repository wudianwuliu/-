# -*- coding: utf-8 -*-
import json
from flask import Blueprint, render_template, request, jsonify
from models import get_db

settings_bp = Blueprint("settings", __name__)


@settings_bp.route("/settings")
def view_settings():
    return render_template("settings.html")


@settings_bp.route("/api/settings/notification")
def api_get_notification_settings():
    db = get_db()
    rows = db.execute("SELECT * FROM notification_config").fetchall()
    result = {}
    for r in rows:
        result[r["channel"]] = {
            "enabled": bool(r["enabled"]),
            **json.loads(r["config_json"]),
        }
    return jsonify(result)


@settings_bp.route("/api/settings/notification", methods=["POST"])
def api_update_notification_settings():
    data = request.get_json()
    channel = data.get("channel", "")
    db = get_db()

    config_fields = {k: v for k, v in data.items() if k not in ("channel", "enabled")}
    db.execute(
        """UPDATE notification_config SET enabled=?, config_json=?
           WHERE channel=?""",
        (1 if data.get("enabled") else 0, json.dumps(config_fields, ensure_ascii=False), channel),
    )
    db.commit()
    return jsonify({"status": "ok"})


@settings_bp.route("/api/settings/demo-services", methods=["POST"])
def api_create_demo_services():
    """创建演示服务用于直观展示"""
    db = get_db()
    demos = [
        ("百度", "http", "https://www.baidu.com", 60, "国内知名搜索引擎"),
        ("GitHub", "http", "https://github.com", 60, "全球最大代码托管平台"),
        ("Python 官网", "http", "https://www.python.org", 60, "Python 官方站点"),
        ("本地 SSH", "tcp", "127.0.0.1:22", 120, "本机 SSH 端口"),
    ]
    for name, stype, target, interval, desc in demos:
        exists = db.execute(
            "SELECT id FROM services WHERE name = ? AND target = ?", (name, target)
        ).fetchone()
        if not exists:
            db.execute(
                "INSERT INTO services (name, type, target, interval, description) VALUES (?, ?, ?, ?, ?)",
                (name, stype, target, interval, desc),
            )
    db.commit()
    return jsonify({"status": "ok", "message": "演示服务已创建"})
