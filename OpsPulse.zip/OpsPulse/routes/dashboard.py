# -*- coding: utf-8 -*-
from flask import Blueprint, render_template, jsonify, request
from models import get_db
from core.monitor import get_latest_check

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/")
def index():
    return render_template("dashboard.html")


@dashboard_bp.route("/api/dashboard/stats")
def dashboard_stats():
    db = get_db()
    services = db.execute("SELECT * FROM services").fetchall()

    total = len(services)
    up_count = 0
    down_count = 0

    for svc in services:
        check = get_latest_check(svc["id"])
        if check and check["status"] == "up":
            up_count += 1
        elif check:
            down_count += 1

    firing = db.execute("SELECT COUNT(*) as cnt FROM alerts WHERE status = 'firing'").fetchone()
    acknowledged = db.execute("SELECT COUNT(*) as cnt FROM alerts WHERE status = 'acknowledged'").fetchone()

    return jsonify({
        "total_services": total,
        "up_count": up_count,
        "down_count": down_count,
        "firing_alerts": firing["cnt"],
        "acknowledged_alerts": acknowledged["cnt"],
    })


@dashboard_bp.route("/api/dashboard/services-status")
def services_status():
    db = get_db()
    services = db.execute("SELECT * FROM services ORDER BY name").fetchall()
    result = []
    for svc in services:
        check = get_latest_check(svc["id"])
        result.append({
            "id": svc["id"],
            "name": svc["name"],
            "type": svc["type"],
            "target": svc["target"],
            "enabled": bool(svc["enabled"]),
            "status": check["status"] if check else "unknown",
            "response_time_ms": check["response_time_ms"] if check else 0,
            "last_checked": check["checked_at"] if check else "-",
        })
    return jsonify(result)


@dashboard_bp.route("/api/dashboard/system-metrics")
def system_metrics_api():
    from core.monitor import get_latest_metrics, get_metrics_history
    latest = get_latest_metrics()
    history = get_metrics_history(60)
    return jsonify({
        "latest": latest,
        "history": history,
    })
