# -*- coding: utf-8 -*-
from flask import Blueprint, render_template, request, jsonify
from models import get_db

alerts_bp = Blueprint("alerts", __name__)


@alerts_bp.route("/alerts")
def list_alerts():
    return render_template("alerts.html")


@alerts_bp.route("/alert-rules")
def list_rules():
    return render_template("alert_rules.html")


@alerts_bp.route("/api/alerts")
def api_list_alerts():
    status = request.args.get("status", "")
    db = get_db()
    if status:
        rows = db.execute(
            "SELECT * FROM alerts WHERE status = ? ORDER BY triggered_at DESC LIMIT 200",
            (status,),
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT * FROM alerts ORDER BY triggered_at DESC LIMIT 200"
        ).fetchall()
    return jsonify([dict(r) for r in rows])


@alerts_bp.route("/api/alerts/<int:alert_id>/acknowledge", methods=["POST"])
def api_acknowledge_alert(alert_id):
    from core.alert_engine import acknowledge_alert
    acknowledge_alert(alert_id)
    return jsonify({"status": "ok"})


@alerts_bp.route("/api/alerts/<int:alert_id>/resolve", methods=["POST"])
def api_resolve_alert(alert_id):
    from core.alert_engine import resolve_alert
    resolve_alert(alert_id)
    return jsonify({"status": "ok"})


@alerts_bp.route("/api/alert-rules")
def api_list_rules():
    db = get_db()
    rows = db.execute("SELECT * FROM alert_rules ORDER BY service_id NULLS FIRST, id").fetchall()
    rules = []
    for r in rows:
        rule = dict(r)
        if rule["service_id"]:
            svc = db.execute("SELECT name FROM services WHERE id = ?", (rule["service_id"],)).fetchone()
            rule["service_name"] = svc["name"] if svc else "已删除"
        else:
            rule["service_name"] = "系统"
        rules.append(rule)
    return jsonify(rules)


@alerts_bp.route("/api/alert-rules", methods=["POST"])
def api_create_rule():
    data = request.get_json()
    db = get_db()
    db.execute(
        """INSERT INTO alert_rules (service_id, metric, operator, threshold, severity)
           VALUES (?, ?, ?, ?, ?)""",
        (data.get("service_id"), data["metric"], data["operator"],
         data["threshold"], data["severity"]),
    )
    db.commit()
    return jsonify({"status": "ok"})


@alerts_bp.route("/api/alert-rules/<int:rule_id>", methods=["PUT"])
def api_update_rule(rule_id):
    data = request.get_json()
    db = get_db()
    db.execute(
        """UPDATE alert_rules SET metric=?, operator=?, threshold=?, severity=?
           WHERE id=?""",
        (data["metric"], data["operator"], data["threshold"], data["severity"], rule_id),
    )
    db.commit()
    return jsonify({"status": "ok"})


@alerts_bp.route("/api/alert-rules/<int:rule_id>", methods=["DELETE"])
def api_delete_rule(rule_id):
    db = get_db()
    db.execute("DELETE FROM alert_rules WHERE id = ?", (rule_id,))
    db.commit()
    return jsonify({"status": "ok"})


@alerts_bp.route("/api/alert-rules/<int:rule_id>/toggle", methods=["POST"])
def api_toggle_rule(rule_id):
    db = get_db()
    rule = db.execute("SELECT * FROM alert_rules WHERE id = ?", (rule_id,)).fetchone()
    if rule:
        db.execute("UPDATE alert_rules SET enabled = ? WHERE id = ?",
                   (0 if rule["enabled"] else 1, rule_id))
        db.commit()
    return jsonify({"status": "ok"})
