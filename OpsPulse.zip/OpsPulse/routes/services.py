# -*- coding: utf-8 -*-
from flask import Blueprint, render_template, request, redirect, url_for, jsonify
from models import get_db

services_bp = Blueprint("services", __name__)


@services_bp.route("/services")
def list_services():
    return render_template("services.html")


@services_bp.route("/api/services")
def api_list_services():
    db = get_db()
    rows = db.execute("SELECT * FROM services ORDER BY name").fetchall()
    return jsonify([dict(r) for r in rows])


@services_bp.route("/api/services", methods=["POST"])
def api_create_service():
    data = request.get_json()
    db = get_db()
    db.execute(
        """INSERT INTO services (name, type, target, interval, timeout, description)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (data["name"], data.get("type", "http"), data["target"],
         int(data.get("interval", 60)), int(data.get("timeout", 10)),
         data.get("description", "")),
    )
    db.commit()
    return jsonify({"status": "ok"})


@services_bp.route("/api/services/<int:service_id>", methods=["PUT"])
def api_update_service(service_id):
    data = request.get_json()
    db = get_db()
    db.execute(
        """UPDATE services SET name=?, type=?, target=?, interval=?, timeout=?, description=?,
           updated_at=datetime('now','localtime') WHERE id=?""",
        (data["name"], data.get("type", "http"), data["target"],
         int(data.get("interval", 60)), int(data.get("timeout", 10)),
         data.get("description", ""), service_id),
    )
    db.commit()
    return jsonify({"status": "ok"})


@services_bp.route("/api/services/<int:service_id>", methods=["DELETE"])
def api_delete_service(service_id):
    db = get_db()
    db.execute("DELETE FROM services WHERE id = ?", (service_id,))
    db.commit()
    return jsonify({"status": "ok"})


@services_bp.route("/api/services/<int:service_id>/toggle", methods=["POST"])
def api_toggle_service(service_id):
    db = get_db()
    svc = db.execute("SELECT * FROM services WHERE id = ?", (service_id,)).fetchone()
    if svc:
        db.execute("UPDATE services SET enabled = ?, updated_at=datetime('now','localtime') WHERE id=?",
                   (0 if svc["enabled"] else 1, service_id))
        db.commit()
    return jsonify({"status": "ok"})


@services_bp.route("/services/<int:service_id>")
def service_detail(service_id):
    db = get_db()
    svc = db.execute("SELECT * FROM services WHERE id = ?", (service_id,)).fetchone()
    if not svc:
        return redirect(url_for("services.list_services"))
    return render_template("service_detail.html", service=dict(svc))


@services_bp.route("/api/services/<int:service_id>/history")
def api_service_history(service_id):
    from core.monitor import get_check_history
    history = get_check_history(service_id, limit=120)
    return jsonify(history)
