# -*- coding: utf-8 -*-
import sqlite3
import os
from datetime import datetime, timezone
from flask import g
from config import Config


def get_db():
    if "db" not in g:
        os.makedirs(os.path.dirname(Config.DATABASE), exist_ok=True)
        g.db = sqlite3.connect(Config.DATABASE, detect_types=sqlite3.PARSE_DECLTYPES)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    os.makedirs(os.path.dirname(Config.DATABASE), exist_ok=True)
    db = sqlite3.connect(Config.DATABASE)
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript("""
    CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL DEFAULT 'http',  -- http, tcp, ping
        target TEXT NOT NULL,               -- URL / host:port / IP
        interval INTEGER NOT NULL DEFAULT 60,
        timeout INTEGER NOT NULL DEFAULT 10,
        enabled INTEGER NOT NULL DEFAULT 1,
        description TEXT DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS check_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        service_id INTEGER NOT NULL,
        status TEXT NOT NULL,               -- up, down, timeout, error
        response_time_ms REAL DEFAULT 0,
        status_code INTEGER DEFAULT 0,
        error_message TEXT DEFAULT '',
        checked_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS system_metrics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cpu_percent REAL DEFAULT 0,
        memory_percent REAL DEFAULT 0,
        memory_used_mb REAL DEFAULT 0,
        disk_percent REAL DEFAULT 0,
        disk_used_gb REAL DEFAULT 0,
        collected_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS alert_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        service_id INTEGER,
        metric TEXT NOT NULL DEFAULT 'status',  -- status, response_time, cpu, memory, disk
        operator TEXT NOT NULL DEFAULT 'eq',    -- eq, ne, gt, lt, gte, lte
        threshold TEXT NOT NULL DEFAULT 'up',
        severity TEXT NOT NULL DEFAULT 'warning',  -- info, warning, critical
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
    );
    -- 当 service_id 为 NULL 时，表示系统级告警规则

    CREATE TABLE IF NOT EXISTS alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        rule_id INTEGER NOT NULL,
        service_id INTEGER,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        severity TEXT NOT NULL DEFAULT 'warning',
        status TEXT NOT NULL DEFAULT 'firing',   -- firing, acknowledged, resolved
        value TEXT DEFAULT '',
        triggered_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        resolved_at TEXT DEFAULT NULL,
        acknowledged_at TEXT DEFAULT NULL,
        FOREIGN KEY (rule_id) REFERENCES alert_rules(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS notification_config (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        channel TEXT NOT NULL UNIQUE,   -- email, webhook, dingtalk
        enabled INTEGER NOT NULL DEFAULT 0,
        config_json TEXT NOT NULL DEFAULT '{}'
    );

    -- Insert default notification channels
    INSERT OR IGNORE INTO notification_config (channel, enabled, config_json) VALUES ('email', 0, '{}');
    INSERT OR IGNORE INTO notification_config (channel, enabled, config_json) VALUES ('webhook', 0, '{}');
    INSERT OR IGNORE INTO notification_config (channel, enabled, config_json) VALUES ('dingtalk', 0, '{}');

    -- Default alert rules for system
    INSERT OR IGNORE INTO alert_rules (id, service_id, metric, operator, threshold, severity) VALUES
        (1, NULL, 'cpu', 'gt', '90', 'critical'),
        (2, NULL, 'memory', 'gt', '90', 'critical'),
        (3, NULL, 'disk', 'gt', '90', 'critical');
    """)
    db.commit()
    db.close()
