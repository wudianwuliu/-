# -*- coding: utf-8 -*-
"""OpsPulse - 全栈监控告警平台"""
import os
from flask import Flask
from config import Config


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    app.config["JSON_AS_ASCII"] = False  # Support Chinese output

    # Initialize database
    from models import init_db, close_db
    with app.app_context():
        init_db()
    app.teardown_appcontext(close_db)

    # Register blueprints
    from routes.dashboard import dashboard_bp
    from routes.services import services_bp
    from routes.alerts import alerts_bp
    from routes.settings import settings_bp

    app.register_blueprint(dashboard_bp)
    app.register_blueprint(services_bp)
    app.register_blueprint(alerts_bp)
    app.register_blueprint(settings_bp)

    # Initialize scheduler
    from apscheduler.schedulers.background import BackgroundScheduler
    scheduler = BackgroundScheduler()
    scheduler._logger.disabled = True

    def monitoring_job():
        """定时执行所有已启用的服务探测"""
        from models import get_db
        from core.monitor import run_check, collect_system_metrics
        from core.alert_engine import evaluate_service_alerts, evaluate_system_alerts

        with app.app_context():
            db = get_db()
            services = db.execute("SELECT * FROM services WHERE enabled = 1").fetchall()

            for svc in services:
                try:
                    result = run_check(dict(svc))
                    evaluate_service_alerts(dict(svc), result)
                except Exception as e:
                    print(f"[监控错误] {svc['name']}: {e}")

            # System metrics
            try:
                metrics = collect_system_metrics()
                evaluate_system_alerts(metrics)
            except Exception as e:
                print(f"[系统指标错误]: {e}")

    # Add job - runs every 30 seconds
    scheduler.add_job(
        monitoring_job,
        "interval",
        seconds=30,
        id="monitoring_job",
        name="服务监控采集",
        replace_existing=True,
    )
    scheduler.start()

    return app


if __name__ == "__main__":
    app = create_app()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
