# OpsPulse - 全栈监控告警平台

## 项目简介

OpsPulse 是一个轻量级的服务监控与告警平台，支持 HTTP/TCP/Ping 三种探测方式，具备系统资源监控、告警规则引擎、多渠道通知和可视化仪表盘等完整功能。相当于一个小型 Prometheus + AlertManager 的组合。

## 核心功能

| 模块 | 功能 |
|------|------|
| **服务监控** | HTTP/HTTPS 健康检查、TCP 端口探测、ICMP Ping 探测 |
| **系统监控** | CPU、内存、磁盘使用率实时采集与趋势展示 |
| **告警引擎** | 灵活的规则配置（状态/响应时间/系统资源）、多级告警（INFO/WARNING/CRITICAL） |
| **通知渠道** | 邮件通知、通用 Webhook、钉钉机器人 |
| **可视化** | 实时状态面板、响应时间趋势图、系统资源历史趋势 |
| **告警管理** | 告警确认、解决、过滤查看 |

## 技术架构

- **后端框架**: Python Flask 3.x
- **数据库**: SQLite (无需外部数据库)
- **定时任务**: APScheduler 3.x
- **监控采集**: requests / socket / subprocess / psutil
- **前端可视化**: ECharts 5.x
- **通知**: smtplib / requests (Webhook / 钉钉)

## 快速启动

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 启动服务
python app.py

# 3. 打开浏览器访问
# http://localhost:5000
```

## 部署方式

### 方式一：直接运行（推荐开发/测试）

```bash
python app.py
```

### 方式二：使用 Gunicorn（生产环境 Linux）

```bash
pip install gunicorn
gunicorn -w 2 -b 0.0.0.0:5000 app:app
```

### 方式三：Systemd 服务（生产环境）

```ini
[Unit]
Description=OpsPulse Monitoring Platform
After=network.target

[Service]
User=root
WorkingDirectory=/opt/OpsPulse
ExecStart=/usr/bin/python3 /opt/OpsPulse/app.py
Restart=always

[Install]
WantedBy=multi-user.target
```

## Linux 虚拟机部署示例

```bash
# 上传项目到服务器
scp -r OpsPulse/ user@your-server:/opt/

# SSH 登录服务器
ssh user@your-server

# 安装依赖
cd /opt/OpsPulse
pip3 install -r requirements.txt

# 后台运行（使用 nohup）
nohup python3 app.py > opspulse.log 2>&1 &

# 查看日志
tail -f opspulse.log
```

## API 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/dashboard/stats | 仪表盘统计信息 |
| GET | /api/dashboard/services-status | 服务实时状态 |
| GET | /api/dashboard/system-metrics | 系统指标 |
| GET/POST | /api/services | 服务列表 / 创建服务 |
| PUT/DELETE | /api/services/{id} | 更新 / 删除服务 |
| GET | /api/services/{id}/history | 服务探测历史 |
| GET | /api/alerts | 告警列表 |
| POST | /api/alerts/{id}/acknowledge | 确认告警 |
| POST | /api/alerts/{id}/resolve | 解决告警 |
| GET/POST | /api/alert-rules | 告警规则管理 |

## 项目结构

```
OpsPulse/
├── app.py              # 应用入口
├── config.py           # 配置文件
├── requirements.txt    # 依赖列表
├── README.md           # 项目文档
├── core/
│   ├── monitor.py      # 监控探测核心
│   ├── alert_engine.py # 告警规则引擎
│   └── notifier.py     # 通知模块
├── models/
│   └── __init__.py     # 数据模型与初始化
├── routes/
│   ├── dashboard.py    # 仪表盘路由
│   ├── services.py     # 服务管理路由
│   ├── alerts.py       # 告警管理路由
│   └── settings.py     # 系统设置路由
├── templates/          # 页面模板
│   ├── base.html
│   ├── dashboard.html
│   ├── services.html
│   ├── service_detail.html
│   ├── alerts.html
│   ├── alert_rules.html
│   └── settings.html
└── static/
    └── css/style.css   # 样式文件
```
