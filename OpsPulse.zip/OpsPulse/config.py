import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "ops-pulse-secret-key-change-in-production")
    DATABASE = os.path.join(BASE_DIR, "data", "opspulse.db")
    SCHEDULER_API_ENABLED = True

    # Default check intervals
    DEFAULT_HTTP_INTERVAL = 60      # seconds
    DEFAULT_TCP_INTERVAL = 60
    DEFAULT_PING_INTERVAL = 120
    DEFAULT_METRIC_INTERVAL = 120

    # Timeout
    HTTP_TIMEOUT = 10               # seconds
    TCP_TIMEOUT = 10
    PING_TIMEOUT = 10

    # Alert defaults
    ALERT_COOLDOWN = 300            # seconds between same alert

    # Notification defaults
    SMTP_SERVER = os.environ.get("SMTP_SERVER", "")
    SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
    SMTP_USER = os.environ.get("SMTP_USER", "")
    SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")
    NOTIFY_FROM = os.environ.get("NOTIFY_FROM", "")
    NOTIFY_TO = os.environ.get("NOTIFY_TO", "")
    WEBHOOK_URL = os.environ.get("WEBHOOK_URL", "")
