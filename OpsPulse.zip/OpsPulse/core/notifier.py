# -*- coding: utf-8 -*-
"""通知模块 - 多渠道告警通知"""

import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
from models import get_db


def send_notification(alert):
    """发送告警通知到所有启用的渠道"""
    db = get_db()
    channels = db.execute(
        "SELECT channel, config_json FROM notification_config WHERE enabled = 1"
    ).fetchall()

    for ch in channels:
        config = json.loads(ch["config_json"])
        channel = ch["channel"]
        try:
            if channel == "email":
                _send_email(alert, config)
            elif channel == "webhook":
                _send_webhook(alert, config)
            elif channel == "dingtalk":
                _send_dingtalk(alert, config)
        except Exception as e:
            print(f"[通知失败] {channel}: {e}")


def _send_email(alert, config):
    """发送邮件通知"""
    smtp_server = config.get("smtp_server", "")
    smtp_port = int(config.get("smtp_port", 587))
    smtp_user = config.get("smtp_user", "")
    smtp_password = config.get("smtp_password", "")
    notify_from = config.get("from_addr", "")
    notify_to = config.get("to_addr", "")

    if not all([smtp_server, smtp_user, smtp_password, notify_from, notify_to]):
        return

    msg = MIMEMultipart()
    msg["From"] = notify_from
    msg["To"] = notify_to
    msg["Subject"] = f"[OpsPulse] {alert['title']}"

    body = f"""
    <h2>OpsPulse 告警通知</h2>
    <table border="1" cellpadding="6" style="border-collapse:collapse;">
        <tr><td><b>标题</b></td><td>{alert['title']}</td></tr>
        <tr><td><b>内容</b></td><td>{alert['message']}</td></tr>
        <tr><td><b>级别</b></td><td>{alert['severity']}</td></tr>
        <tr><td><b>时间</b></td><td>{alert['triggered_at']}</td></tr>
    </table>
    """
    msg.attach(MIMEText(body, "html"))

    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        server.login(smtp_user, smtp_password)
        server.send_message(msg)


def _send_webhook(alert, config):
    """发送通用 Webhook 通知"""
    url = config.get("url", "")
    if not url:
        return

    payload = {
        "title": alert["title"],
        "message": alert["message"],
        "severity": alert["severity"],
        "timestamp": alert["triggered_at"],
        "source": "OpsPulse",
    }
    headers = {"Content-Type": "application/json"}
    requests.post(url, json=payload, headers=headers, timeout=10)


def _send_dingtalk(alert, config):
    """发送钉钉机器人通知"""
    url = config.get("webhook_url", "")
    if not url:
        url = config.get("url", "")
    if not url:
        return

    severity_colors = {"info": "87CEFA", "warning": "FFA500", "critical": "FF0000"}
    color = severity_colors.get(alert["severity"], "87CEFA")

    payload = {
        "msgtype": "markdown",
        "markdown": {
            "title": f"【OpsPulse】{alert['title']}",
            "text": f"### OpsPulse 告警通知\n"
                    f"> **标题:** {alert['title']}\n\n"
                    f"> **内容:** {alert['message']}\n\n"
                    f"> **级别:** <font color='#{color}'>{alert['severity']}</font>\n\n"
                    f"> **时间:** {alert['triggered_at']}"
        },
    }
    headers = {"Content-Type": "application/json"}
    requests.post(url, json=payload, headers=headers, timeout=10)
