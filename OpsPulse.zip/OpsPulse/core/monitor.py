# -*- coding: utf-8 -*-
"""监控核心模块 - 服务健康探测与系统指标采集"""
import time
import socket
import subprocess
import platform
import requests
from datetime import datetime, timezone
from models import get_db


def check_http(service):
    """HTTP/HTTPS 健康探测"""
    target = service["target"]
    timeout = service["timeout"]
    start = time.time()
    try:
        resp = requests.get(
            target,
            timeout=timeout,
            headers={"User-Agent": "OpsPulse-Monitor/1.0"},
            allow_redirects=True,
        )
        elapsed = (time.time() - start) * 1000
        return {
            "status": "up" if resp.status_code < 500 else "down",
            "response_time_ms": round(elapsed, 2),
            "status_code": resp.status_code,
            "error": "",
        }
    except requests.Timeout:
        elapsed = (time.time() - start) * 1000
        return {"status": "timeout", "response_time_ms": round(elapsed, 2), "status_code": 0, "error": "请求超时"}
    except requests.ConnectionError as e:
        elapsed = (time.time() - start) * 1000
        return {"status": "down", "response_time_ms": round(elapsed, 2), "status_code": 0, "error": f"连接失败: {str(e)[:80]}"}
    except Exception as e:
        elapsed = (time.time() - start) * 1000
        return {"status": "error", "response_time_ms": round(elapsed, 2), "status_code": 0, "error": str(e)[:100]}


def check_tcp(service):
    """TCP 端口探测"""
    target = service["target"]
    timeout = service["timeout"]
    host, _, port_str = target.partition(":")
    try:
        port = int(port_str)
    except ValueError:
        return {"status": "error", "response_time_ms": 0, "status_code": 0, "error": f"端口格式错误: {target}"}

    start = time.time()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        elapsed = (time.time() - start) * 1000
        if result == 0:
            return {"status": "up", "response_time_ms": round(elapsed, 2), "status_code": 0, "error": ""}
        else:
            return {"status": "down", "response_time_ms": round(elapsed, 2), "status_code": result, "error": f"端口未开放 (code={result})"}
    except socket.timeout:
        elapsed = (time.time() - start) * 1000
        return {"status": "timeout", "response_time_ms": round(elapsed, 2), "status_code": 0, "error": "连接超时"}
    except Exception as e:
        elapsed = (time.time() - start) * 1000
        return {"status": "error", "response_time_ms": round(elapsed, 2), "status_code": 0, "error": str(e)[:100]}


def check_ping(service):
    """ICMP Ping 探测"""
    target = service["target"]
    timeout = service["timeout"]
    param = "-n" if platform.system().lower() == "windows" else "-c"
    timeout_param = "-w" if platform.system().lower() == "windows" else "-W"

    start = time.time()
    try:
        cmd = ["ping", param, "1", target]
        if platform.system().lower() == "windows":
            cmd.extend(["-w", str(int(timeout) * 1000)])
        else:
            cmd.extend(["-W", str(int(timeout))])

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout + 2,
        )
        elapsed = (time.time() - start) * 1000

        if result.returncode == 0:
            # Extract time from output
            import re
            match = re.search(r"(?:time|时间)[=<]\s*([\d.]+)\s*ms", result.stdout, re.IGNORECASE)
            ping_time = float(match.group(1)) if match else round(elapsed, 2)
            return {"status": "up", "response_time_ms": ping_time, "status_code": 0, "error": ""}
        else:
            return {"status": "down", "response_time_ms": round(elapsed, 2), "status_code": result.returncode, "error": "Ping 无响应"}
    except subprocess.TimeoutExpired:
        elapsed = (time.time() - start) * 1000
        return {"status": "timeout", "response_time_ms": round(elapsed, 2), "status_code": 0, "error": "Ping 超时"}
    except Exception as e:
        elapsed = (time.time() - start) * 1000
        return {"status": "error", "response_time_ms": round(elapsed, 2), "status_code": 0, "error": str(e)[:100]}


def run_check(service):
    """执行探测并保存结果"""
    checkers = {"http": check_http, "https": check_http, "tcp": check_tcp, "ping": check_ping}
    checker = checkers.get(service["type"], check_http)
    result = checker(service)

    db = get_db()
    db.execute(
        """INSERT INTO check_results (service_id, status, response_time_ms, status_code, error_message)
           VALUES (?, ?, ?, ?, ?)""",
        (service["id"], result["status"], result["response_time_ms"], result["status_code"], result["error"]),
    )
    db.commit()
    return result


def collect_system_metrics():
    """采集系统指标（CPU/内存/磁盘）"""
    import psutil
    cpu_percent = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")

    db = get_db()
    db.execute(
        """INSERT INTO system_metrics (cpu_percent, memory_percent, memory_used_mb, disk_percent, disk_used_gb)
           VALUES (?, ?, ?, ?, ?)""",
        (round(cpu_percent, 1), round(mem.percent, 1), round(mem.used / 1024 / 1024, 1),
         round(disk.percent, 1), round(disk.used / 1024 / 1024 / 1024, 2)),
    )
    db.commit()
    return {
        "cpu_percent": cpu_percent,
        "memory_percent": mem.percent,
        "memory_used_mb": round(mem.used / 1024 / 1024, 1),
        "disk_percent": disk.percent,
        "disk_used_gb": round(disk.used / 1024 / 1024 / 1024, 2),
    }


def get_latest_check(service_id):
    """获取指定服务的最新探测结果"""
    db = get_db()
    row = db.execute(
        "SELECT * FROM check_results WHERE service_id = ? ORDER BY checked_at DESC LIMIT 1",
        (service_id,),
    ).fetchone()
    return dict(row) if row else None


def get_check_history(service_id, limit=60):
    """获取探测历史"""
    db = get_db()
    rows = db.execute(
        "SELECT * FROM check_results WHERE service_id = ? ORDER BY checked_at DESC LIMIT ?",
        (service_id, limit),
    ).fetchall()
    return [dict(r) for r in rows]


def get_latest_metrics():
    """获取最新的系统指标"""
    db = get_db()
    row = db.execute("SELECT * FROM system_metrics ORDER BY collected_at DESC LIMIT 1").fetchone()
    return dict(row) if row else None


def get_metrics_history(limit=120):
    """获取历史系统指标"""
    db = get_db()
    rows = db.execute("SELECT * FROM system_metrics ORDER BY collected_at DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]
