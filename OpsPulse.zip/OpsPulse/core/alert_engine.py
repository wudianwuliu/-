# -*- coding: utf-8 -*-
"""告警引擎 - 评估告警规则并生成告警"""
from datetime import datetime, timezone
from models import get_db


def evaluate_service_alerts(service, check_result):
    """评估某服务的告警规则"""
    db = get_db()
    rules = db.execute(
        "SELECT * FROM alert_rules WHERE (service_id = ? OR service_id IS NULL) AND enabled = 1",
        (service["id"],),
    ).fetchall()

    for rule in rules:
        value = _get_metric_value(rule, check_result)
        if value is None:
            continue

        if _evaluate_condition(float(value) if isinstance(value, (int, float)) else value, rule["operator"], rule["threshold"]):
            _create_or_update_alert(db, rule, service, value)


def evaluate_system_alerts(system_metrics):
    """评估系统级告警规则"""
    db = get_db()
    rules = db.execute(
        "SELECT * FROM alert_rules WHERE service_id IS NULL AND enabled = 1"
    ).fetchall()

    for rule in rules:
        value = _get_system_metric_value(rule, system_metrics)
        if value is None:
            continue

        threshold = float(rule["threshold"])
        if _evaluate_condition(value, rule["operator"], threshold):
            _create_or_update_alert(db, rule, None, value)


def _get_metric_value(rule, check_result):
    """从探测结果中提取告警规则对应的值"""
    metric = rule["metric"]
    if metric == "status":
        status_map = {"up": 0, "down": 1, "timeout": 2, "error": 3}
        return status_map.get(check_result.get("status", "error"), 3)
    elif metric == "response_time":
        return check_result.get("response_time_ms", 0)
    return None


def _get_system_metric_value(rule, metrics):
    """从系统指标中提取值"""
    metric = rule["metric"]
    if metric == "cpu":
        return metrics.get("cpu_percent", 0)
    elif metric == "memory":
        return metrics.get("memory_percent", 0)
    elif metric == "disk":
        return metrics.get("disk_percent", 0)
    return None


def _evaluate_condition(value, operator, threshold):
    """评估条件表达式"""
    try:
        t = float(threshold) if threshold.replace(".", "").isdigit() else threshold
    except (ValueError, AttributeError):
        t = threshold

    if operator == "eq":
        return value == t
    elif operator == "ne":
        return value != t
    elif operator == "gt":
        return float(value) > float(t)
    elif operator == "lt":
        return float(value) < float(t)
    elif operator == "gte":
        return float(value) >= float(t)
    elif operator == "lte":
        return float(value) <= float(t)

    # Handle textual status checks
    if isinstance(t, str):
        if operator == "eq":
            return str(value) == t
        elif operator == "ne":
            return str(value) != t

    return False


def _create_or_update_alert(db, rule, service, value):
    """创建或更新告警（去重 + cooldown）"""
    from config import Config

    service_id = service["id"] if service else None
    service_name = service["name"] if service else "系统"

    # Check if there's already a firing alert for this rule
    existing = db.execute(
        """SELECT id FROM alerts
           WHERE rule_id = ? AND service_id IS ? AND status = 'firing'
           ORDER BY triggered_at DESC LIMIT 1""",
        (rule["id"], service_id),
    ).fetchone()

    if existing:
        return  # Already firing, skip

    # Check cooldown
    recent = db.execute(
        """SELECT triggered_at FROM alerts
           WHERE rule_id = ? AND service_id IS ?
           ORDER BY triggered_at DESC LIMIT 1""",
        (rule["id"], service_id),
    ).fetchone()

    if recent:
        from datetime import datetime
        last_time = datetime.strptime(recent["triggered_at"], "%Y-%m-%d %H:%M:%S")
        now = datetime.now()
        diff = (now - last_time).total_seconds()
        if diff < Config.ALERT_COOLDOWN:
            return

    title = f"[{rule['severity'].upper()}] {service_name} - {rule['metric']}"
    message = f"服务: {service_name} | 指标: {rule['metric']} | 规则: {rule['metric']} {rule['operator']} {rule['threshold']} | 当前值: {value}"

    db.execute(
        """INSERT INTO alerts (rule_id, service_id, title, message, severity, value)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (rule["id"], service_id, title, message, rule["severity"], str(value)),
    )
    db.commit()


def resolve_alert(alert_id):
    """确认并解决告警"""
    db = get_db()
    db.execute(
        "UPDATE alerts SET status = 'resolved', resolved_at = datetime('now', 'localtime') WHERE id = ?",
        (alert_id,),
    )
    db.commit()


def acknowledge_alert(alert_id):
    """确认告警"""
    db = get_db()
    db.execute(
        "UPDATE alerts SET status = 'acknowledged', acknowledged_at = datetime('now', 'localtime') WHERE id = ?",
        (alert_id,),
    )
    db.commit()
